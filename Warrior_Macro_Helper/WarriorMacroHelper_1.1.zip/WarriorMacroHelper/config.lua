-- config.lua
WMH_DB = WMH_DB or {}
